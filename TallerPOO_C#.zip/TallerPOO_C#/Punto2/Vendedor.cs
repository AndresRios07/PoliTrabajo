﻿using Punto2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Punto2
{
    internal class Vendedor : Empleado
    {
        private string matriculaCoche;
        private string marcaCoche;
        private string modeloCoche;
        private string telefonoMovil;
        private string areaVenta;
        private List<string> listaClientes;
        private double comision;


        public Vendedor(string nombre, string apellidos, string dni, string direccion, string telefono, double salario, string matriculaCoche, string marcaCoche, string modeloCoche, string telefonoMovil, string areaVenta, double comision)
            : base(nombre, apellidos, dni, direccion, telefono, salario)
        {
            this.matriculaCoche = matriculaCoche;
            this.marcaCoche = marcaCoche;
            this.modeloCoche = modeloCoche;
            this.telefonoMovil = telefonoMovil;
            this.areaVenta = areaVenta;
            this.comision = comision;
            listaClientes = new List<string>();
        }

        public override void Imprimir()
        {
            base.Imprimir();
            Console.WriteLine("Matrícula del Coche: " + matriculaCoche);
            Console.WriteLine("Marca del Coche: " + marcaCoche);
            Console.WriteLine("Modelo del Coche: " + modeloCoche);
            Console.WriteLine("Teléfono Móvil: " + telefonoMovil);
            Console.WriteLine("Área de Venta: " + areaVenta);
            Console.WriteLine("Comisión: " + comision);
        }

        public void DarDeAltaCliente(string cliente)
        {
            listaClientes.Add(cliente);
        }

        public void DarDeBajaCliente(string cliente)
        {
            listaClientes.Remove(cliente);
        }

        public void CambiarCoche(string matricula, string marca, string modelo)
        {
            this.matriculaCoche = matricula;
            this.marcaCoche = marca;
            this.modeloCoche = modelo;
        }
    }
}
