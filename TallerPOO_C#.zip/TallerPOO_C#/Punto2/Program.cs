﻿using Punto2;

class Program
{
    static void Main(string[] args)
    {
        Secretario secretario1 = new Secretario
            ("Maria", "Gomez", "87654321B", "Calle Secundaria 456", 
            "987654321", 1500, "Despacho 1", "123456789");

        Console.WriteLine("Datos del secretario:");
        secretario1.Imprimir();
        Console.WriteLine();

        Vendedor vendedor1 = new Vendedor
            ("Pedro", "Lopez", "56789012C", "Calle Principal 789", 
            "123456789", 2000, "ABC123", "Toyota", "Corolla", "987654321", 
            "Zona Norte", 0.05);

        Console.WriteLine("Datos del vendedor:");
        vendedor1.Imprimir();
        Console.WriteLine();
    }
}