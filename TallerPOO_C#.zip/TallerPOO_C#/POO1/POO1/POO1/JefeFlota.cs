﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO1
{
    internal class JefeFlota: Tripulante
    {
        //Atributos
        private int pesoPescados;
        private float bonoPescados;
        private int pesoMariscos;
        private float bonoMariscos;
        private const int sueldo = 350000000;
        private int sueldoTotal;

        //Constructor
        public JefeFlota(int numeroCarnet, int edad, int tiempoTrabajando, string nombreTripulante, string telefono, string sexo, int pesoPescado, float bonoPescado, int pesoMariscos, float bonoMariscos, int sueldoTotal) : base(numeroCarnet, edad, tiempoTrabajando, nombreTripulante, telefono, sexo)
        {
            this.bonoMariscos = bonoMariscos;
            this.bonoPescados = bonoPescado;
            this.pesoMariscos = pesoMariscos;
            this.pesoPescados = pesoPescado;
            this.sueldoTotal = sueldoTotal;
        }

        //GET Y SET
        public int PesoPescados { get => pesoPescados; set => pesoPescados = value; }
        public float BonoPescados { get => bonoPescados; set => bonoPescados = value; }
        public int PesoMariscos { get => pesoMariscos; set => pesoMariscos = value; }
        public float BonoMariscos { get => bonoMariscos; set => bonoMariscos = value; }
        public int SueldoTotal { get => sueldoTotal; set => sueldoTotal = value; }

        //Metodos Abstractos Heredados
        public override void Sueldo()
        {
            BonoPescados = PesoPescados;
            BonoMariscos = PesoMariscos*2;
            SueldoTotal = (int)(sueldo*BonoPescados/100) + (int)(sueldo * BonoMariscos /100) + sueldo;

        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"Bono mariscos: {BonoMariscos}" +
                $"\nBono pescados: {BonoPescados}" +
                $"\nPeso pescados: {PesoPescados}" +
                $"\nPeso mariscos {PesoMariscos}" +
                $"\nSueldo Total: {SueldoTotal}");
        }
    }
}
