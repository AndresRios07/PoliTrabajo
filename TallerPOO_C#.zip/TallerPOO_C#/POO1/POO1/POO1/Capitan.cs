﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO1
{
    internal class Capitan : Tripulante
    {
        //Atributos
        private int horasExperiencia;
        private const int sueldo = 4500000;
        private int sueldoTotal;
        private float bono;

        //Constructor
        public Capitan(int numeroCarnet, int edad, int tiempoTrabajando, string nombreTripulante, string telefono, string sexo, int horasExperiencia, int sueldoTotal, float bono) : base(numeroCarnet, edad, tiempoTrabajando, nombreTripulante, telefono, sexo)
        {
            this.horasExperiencia = horasExperiencia;
            this.sueldoTotal = sueldoTotal;
            this.bono = bono;
        }

        //GET Y SET
        public int HorasExperiencia { get => horasExperiencia; set => horasExperiencia = value; }
        public int SueldoTotal { get => sueldoTotal; set => sueldoTotal = value; }
        public float Bono { get => bono; set => bono = value; }
        

        //Metodos Abstractos Heredados
        public override void Sueldo()
        {
            if (horasExperiencia > 5000 && horasExperiencia < 150000)
            {
                Bono = (int)(sueldo * 0.2);
                SueldoTotal = (int)(sueldo + Bono);
            }
            else if (horasExperiencia > 150000 && horasExperiencia < 300000)
            {
                Bono = (int)(sueldo * 0.4);
                SueldoTotal = (int)(sueldo + Bono);
            }
            else
            {
                Bono = (int)(sueldo * 0.75);
                SueldoTotal = (int)(sueldo + Bono);
            }
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"Horas Experiencia: {HorasExperiencia}" +
                $"\nSueldo: {sueldo}" +
                $"\nSueldo Total: {SueldoTotal}" +
                $"\nBono: {Bono}");
        }
    }
}
