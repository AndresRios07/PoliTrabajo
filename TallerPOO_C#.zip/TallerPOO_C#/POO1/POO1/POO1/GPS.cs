﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO1
{
    internal class GPS:Barco
    {
        //Atributos
        private double coordenadaX;
        private double coordenadaY;
        private string fecha;
        private string hora;
        private int diasTripulados;

        //Constructor
        public GPS(string nombre, int capacidadPasajero, int capacidadCarga, double coordenadaX, double coordenadaY, string fecha, string hora, int diasTripulados) : base(nombre, capacidadPasajero, capacidadCarga)
        {
            this.coordenadaX = coordenadaX;
            this.coordenadaY = coordenadaY;
            this.fecha = fecha;
            this.hora = hora;
            this.diasTripulados = diasTripulados;
        }

        //GET Y SET
        public double CoordenadaX { get => coordenadaX; set => coordenadaX = value; }
        public double CoordenadaY { get => coordenadaY; set => coordenadaY = value; }
        public string Fecha { get => fecha; set => fecha = value; }
        public string Hora { get => hora; set => hora = value; }
        public int DiasTripulados { get => diasTripulados; set => diasTripulados = value; }

        //Metodo
        public void MostrarInfo()
        {
            Console.WriteLine($"\nCoordenada X: {CoordenadaX}" +
                $"\nCoordenada Y: {CoordenadaY}" +
                $"\nFecha: {Fecha}" +
                $"\nHora: {Hora}" +
                $"\nDías Tripulados: {DiasTripulados}"
                );
        }
    }
}
