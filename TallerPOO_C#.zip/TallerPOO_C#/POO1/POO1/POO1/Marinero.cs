﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO1
{
    internal class Marinero: Tripulante
    {
        //Atributos
        private int pesoTotalPescado;
        private const int sueldo = 90000;
        private int sueldoTotal;
        private float bono;

        //Constructor
        public Marinero(int numeroCarnet, int edad, int tiempoTrabajando, string nombreTripulante, string telefono, string sexo, int pesoTotalPescado, int sueldoTotal, float bono) : base(numeroCarnet, edad, tiempoTrabajando, nombreTripulante, telefono, sexo)
        {
            this.pesoTotalPescado = pesoTotalPescado;
            this.sueldoTotal = sueldoTotal;
            this.bono = bono;
        }

        //GET Y SET
        public int PesoTotalPescado { get => pesoTotalPescado; set => pesoTotalPescado = value; }
        public int SueldoTotal { get => sueldoTotal; set => sueldoTotal = value; }
        public float Bono { get => bono; set => bono = value; }

        //Metodos Abstractos Heredados
        public override void Sueldo()
        {
            if(PesoTotalPescado >= 1)
            {
                Bono = (float)(PesoTotalPescado * 0.25);
                SueldoTotal = (int)(sueldo * Bono / 100) + sueldo;
            }

        }

        public override void MostrarInfo()
        {
            Console.WriteLine();
        }
    }
}
