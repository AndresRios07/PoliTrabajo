﻿using POO1;
using System.Security.Cryptography.X509Certificates;

class Principal
{
    public static void Main()
    {
        Barco barco = new Barco("",0,0);
        GPS gps = new GPS("",0,0,0.0,0.0,"","",0);
        Capitan capitan = new Capitan(0,0,0,"","","",0,0,0);
        JefeFlota jefeFlota = new JefeFlota(0,0,0,"","","",0,0,0,0,0);
        Marinero marinero = new Marinero(0, 0, 0, "", "", "", 0, 0, 0); ;
        List<Marinero> listMarinero = new List<Marinero>();

        int opc = 0;
        do
        {
            Console.WriteLine("\nOpciones" +
                "\n0. Salir" +
                "\n1. Barco" +
                "\n2. GPS" +
                "\n3. Capitan" +
                "\n4. Jefe Flota" +
                "\n5. Marinero" +
                "\n6. Listar Marineros" +
                "\nElige:");
            opc = Convert.ToInt32(Console.ReadLine());
            switch (opc)
            {
                case 0:
                    Console.WriteLine("Haz salido del sistema");
                    break;
                case 1:
                    Console.WriteLine("\nBarco");
                    Console.WriteLine("\nNombre del barco: ");
                    barco.Nombre = Console.ReadLine();
                    Console.WriteLine("Capacidad de pasajeros: ");
                    barco.CapacidadPasajero = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Capacidad de carga: ");
                    barco.CapacidadCarga = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("\nDatos ingresados");
                    barco.MostrarDatos();
                    break;

                    case 2:
                    Console.WriteLine("\nGPS");
                    Console.WriteLine("\nNombre del barco: ");
                    gps.Nombre = Console.ReadLine();
                    Console.WriteLine("Capacidad de pasajeros: ");
                    gps.CapacidadPasajero = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Capacidad de carga: ");
                    gps.CapacidadCarga = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Coordenada X: ");
                    gps.CoordenadaX = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Coordenada Y: ");
                    gps.CoordenadaY = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Fecha: : ");
                    gps.Fecha = Console.ReadLine();
                    Console.WriteLine("Hora: ");
                    gps.Hora = Console.ReadLine();
                    Console.WriteLine("Días Tripulados: ");
                    gps.DiasTripulados = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("\nDatos ingresados");
                    Console.WriteLine($"\nNombre: {gps.Nombre}" +
                        $"\nCapacidad pasajeros: {gps.CapacidadPasajero}" +
                        $"\nCapacidad carga: {gps.CapacidadCarga}");
                    gps.MostrarInfo();
                    break;

                    case 3:
                    Console.WriteLine("\nCapitan");
                    Console.WriteLine("Numero de carnet: ");
                    capitan.NumeroCarnet = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Edad: ");
                    capitan.Edad = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Tiempo trabajando: ");
                    capitan.TiempoTrabajando = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Nombre tripulante: ");
                    capitan.NombreTripulante = Console.ReadLine();
                    Console.WriteLine("Telefono: ");
                    capitan.Telefono = Console.ReadLine();
                    Console.WriteLine("Sexo: ");
                    capitan.Sexo = Console.ReadLine();
                    Console.WriteLine("Horas de experiencia: ");
                    capitan.HorasExperiencia = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("\nDatos ingresados");
                    Console.WriteLine($"\nNumero carnet: {capitan.NumeroCarnet}" +
                        $"\nEdad: {capitan.Edad}" +
                        $"\nTiempo trabajando: {capitan.TiempoTrabajando}" +
                        $"\nNombre tripulante: {capitan.NombreTripulante}" +
                        $"\nTelefono: {capitan.Telefono}" +
                        $"\nSexo: {capitan.Sexo}"
                        );
                    capitan.Sueldo();
                    capitan.MostrarInfo();
                    break;

                    case 4:
                    Console.WriteLine("\nJefe Flota");
                    Console.WriteLine("\nNumero de carnet: ");
                    jefeFlota.NumeroCarnet = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Edad: ");
                    jefeFlota.Edad = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Tiempo trabajando: ");
                    jefeFlota.TiempoTrabajando = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Nombre tripulante: ");
                    jefeFlota.NombreTripulante = Console.ReadLine();
                    Console.WriteLine("Telefono: ");
                    jefeFlota.Telefono = Console.ReadLine();
                    Console.WriteLine("Sexo: ");
                    jefeFlota.Sexo = Console.ReadLine();
                    Console.WriteLine("Peso Pescado: ");
                    jefeFlota.PesoPescados = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Peso Mariscos: ");
                    jefeFlota.PesoMariscos = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("\nDatos ingresados");
                    Console.WriteLine($"\nNumero carnet: {jefeFlota.NumeroCarnet}" +
                        $"\nEdad: {jefeFlota.Edad}" +
                        $"\nTiempo trabajando: {jefeFlota.TiempoTrabajando}" +
                        $"\nNombre tripulante: {jefeFlota.NombreTripulante}" +
                        $"\nTelefono: {jefeFlota.Telefono}" +
                        $"\nSexo: {jefeFlota.Sexo}"
                        );
                    jefeFlota.Sueldo();
                    jefeFlota.MostrarInfo();
                    break;

                    case 5:
                    Console.WriteLine("\nJefe Flota");
                    Console.WriteLine("\nNumero de carnet: ");
                    int numCarnet = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Edad: ");
                    int edad = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Tiempo trabajando: ");
                    int tiempoTrabajado = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Nombre tripulante: ");
                    string nombreTripulante = Console.ReadLine();
                    Console.WriteLine("Telefono: ");
                    string telefono = Console.ReadLine();
                    Console.WriteLine("Sexo: ");
                    string sexo = Console.ReadLine();
                    Console.WriteLine("Peso Total Pescado: ");
                    int totalPescado = Convert.ToInt32(Console.ReadLine());
                    marinero.Sueldo();
                    marinero = new Marinero(numCarnet, edad, tiempoTrabajado, nombreTripulante, telefono, sexo, totalPescado, marinero.SueldoTotal, marinero.Bono);
                    listMarinero.Add(marinero);
                    break;

                case 6:
                    if (marinero == null)
                    {
                        Console.WriteLine("Error: Ingresa información");
                    }
                    else
                    {
                        foreach (Marinero marinero1 in listMarinero)
                        {
                            mostrarMarinero(marinero1);
                            Console.WriteLine();
                        }

                        static void mostrarMarinero(Marinero marinero)
                        {
                            Console.WriteLine($"\nNumero carnet: {marinero.NumeroCarnet}" +
                            $"\nEdad: {marinero.Edad}" +
                            $"\nTiempo trabajando: {marinero.TiempoTrabajando}" +
                            $"\nNombre tripulante: {marinero.NombreTripulante}" +
                            $"\nTelefono: {marinero.Telefono}" +
                            $"\nSexo: {marinero.Sexo}" +
                            $"\nPeso Total Pescado: {marinero.PesoTotalPescado}" +
                            $"\nSueldo Total: {marinero.SueldoTotal}" +
                            $"\nBono: {marinero.Bono}"
                            );
                        }
                    }
                    break;

                default:
                    Console.WriteLine("Error: Ingresa una opción valida");
                    break;

            }
        } while (opc != 0);
    }
}
