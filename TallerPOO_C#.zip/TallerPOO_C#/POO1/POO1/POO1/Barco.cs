﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO1
{
    internal class Barco
    {
        //Atributo
        private string nombre;
        private int capacidadPasajero;
        private int capacidadCarga;

        //Constructor
        public Barco(string nombre, int capacidadPasajero, int capacidadCarga)
        {
            this.nombre = nombre;
            this.capacidadPasajero = capacidadPasajero;
            this.capacidadCarga = capacidadCarga;
        }

        //GET Y SET
        public string Nombre { get => nombre; set => nombre = value; }
        public int CapacidadPasajero { get => capacidadPasajero; set => capacidadPasajero = value; }
        public int CapacidadCarga { get => capacidadCarga; set => capacidadCarga = value; }

        //Metodo
        public void MostrarDatos()
        {
            Console.WriteLine($"\nNombre: {Nombre}" +
                $"\nCapacidad Pasajeros: {CapacidadPasajero}" +
                $"\nCapacidad Carga: {CapacidadCarga}");
        }
    }
}
