﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO1
{
    internal abstract class Tripulante
    {
        //Atributos
        private int numeroCarnet;
        private int edad;
        private int tiempoTrabajando;
        private string nombreTripulante;
        private string telefono;
        private string sexo;

        //Constructor
        public Tripulante(int numeroCarnet, int edad, int tiempoTrabajando, string nombreTripulante, string telefono, string sexo)
        {
            this.numeroCarnet = numeroCarnet;
            this.edad = edad;
            this.tiempoTrabajando = tiempoTrabajando;
            this.nombreTripulante = nombreTripulante;
            this.telefono = telefono;
            this.sexo = sexo;
        }

        //GET Y SET
        public int NumeroCarnet { get => numeroCarnet; set => numeroCarnet = value; }
        public int Edad { get => edad; set => edad = value; }
        public int TiempoTrabajando { get => tiempoTrabajando; set => tiempoTrabajando = value; }
        public string NombreTripulante { get => nombreTripulante; set => nombreTripulante = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Sexo { get => sexo; set => sexo = value; }

        //Metodos Abstractos
        public abstract void Sueldo();
        public abstract void MostrarInfo();
    }
}
