﻿using System;

namespace PuntoThree
{
    public class Camion : Vehiculo
    {
        private Remolque remolque;

        public Camion(string matricula) : base(matricula)
        {
            remolque = null;
        }

        public void PonRemolque(Remolque rem)
        {
            remolque = rem;
        }

        public void QuitaRemolque()
        {
            remolque = null;
        }

        public virtual void Acelerar(double cantidad)
        {
            if (remolque != null && GetVelocidad() + cantidad > 100)
            {
               throw new DemasiadoRapidoException("vas rapido parce");
            }
            base.Acelerar(cantidad);
        }

        private void DemasiadoRapido()
        {
            Console.WriteLine("¡Vas demasiado rápido!");
        }

        public override string ToString()
        {
            if (remolque != null)
            {
                return base.ToString() + ". Lleva un remolque: " + remolque.ToString();
            }
            else
            {
                return base.ToString();
            }
        }
    }

    public class Remolque
    {
        private int peso;

        public Remolque(int peso)
        {
            this.peso = peso;
        }

        public override string ToString()
        {
            return "Remolque con un peso de " + peso + " kg";
        }
    }
}
