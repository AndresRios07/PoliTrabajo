﻿using System;

namespace PuntoThree
{
    class Program
    {
        static void Main(string[] args)
        {
            Camion camion = new Camion("ABC123");

            Remolque remolque = new Remolque(500);

            camion.PonRemolque(remolque);

            camion.Acelerar(110);

            try
            {
                camion.Acelerar(101);

            }
            catch (DemasiadoRapidoException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine(camion.ToString());

            camion.QuitaRemolque();

        }
    }
}
