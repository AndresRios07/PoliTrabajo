﻿using System;

namespace PuntoThree
{
    public class DemasiadoRapidoException : Exception
    {
        public DemasiadoRapidoException() : base()
        {
        }

        public DemasiadoRapidoException(string mensaje) : base(mensaje)
        {
        }
    }
}
