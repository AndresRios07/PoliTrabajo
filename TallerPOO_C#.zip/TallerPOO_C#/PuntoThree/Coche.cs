﻿using System;

namespace PuntoThree
{
    public class Coche : Vehiculo
    {
        private int numeroPuertas;

        public Coche(string matricula, int numPuertas) : base(matricula)
        {
            numeroPuertas = numPuertas;
        }

        public int TotalPuertas()
        {
            return numeroPuertas;
        }
    }
}
