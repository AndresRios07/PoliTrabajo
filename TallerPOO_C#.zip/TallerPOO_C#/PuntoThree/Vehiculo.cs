﻿using System;

namespace PuntoThree
{
    public class Vehiculo
    {
        private string matricula;
        private double velocidad;

        public string Matricula { get => matricula; set => matricula = value; }
        public double Velocidad { get => velocidad; set => velocidad = value; }

        public Vehiculo(string matricula)
        {
            this.Matricula = matricula;
            this.Velocidad = 0;
        }

        public double GetVelocidad()
        {
            return Velocidad;
        }

        public void SetVelocidad(double velocidad)
        {
            this.Velocidad = velocidad;
        }

        public void Acelerar(double cantidad)
        {
            Velocidad += cantidad;
        }

        public override string ToString()
        {
            return "El vehículo con matrícula " + Matricula + " va a velocidad de " + Velocidad + " km/h";
        }
    }
}
